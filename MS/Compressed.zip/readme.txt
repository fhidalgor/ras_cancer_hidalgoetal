Jupyter notebooks used to plot data for HDX-MS performed on WT Ras

Peptides plotted here are those that had very little overlap with nearby peptides, leading to clean spectra
- Peptides selected cover nearly all of the Ras sequence; most display EX2 behavior
- Multiple peptides covering the N-terminal and C-terminal regions that display EX1 behavior selected as well

Peptide spectra exported from HDExaminer Sessions. 

In some cases, peptides had more than one charge state; the first (lowest) charge state was typically selected for plotting

Two biological replicates performed on separate days 

